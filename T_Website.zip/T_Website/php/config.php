<?php
$host = "localhost";  // Server
$username = "root";   // Default is "root"
$password = "";       // Default is empty (change if necessary)
$database = "login";  // Ensure this matches the database name

$conn = new mysqli("localhost", "root", "", "login");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Database connection successful!";
?>